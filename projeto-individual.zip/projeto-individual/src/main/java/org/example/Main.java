package org.example;

import java.util.HashMap;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Maquina user = new Maquina();
        Scanner leitor = new Scanner(System.in);

            System.out.println("Nome do usuário:\n");
                String nomeUsuario = leitor.nextLine();
            System.out.println("Senha do usuário:\n");
                String senhaUsuario = leitor.nextLine();
                    user.setNome(nomeUsuario);
                    user.setSenha(senhaUsuario);
            user.cadastro();
            System.out.println("Agora você está no sistema" + user.nome);
            System.out.println("Faça o login para confirmação:");
            System.out.println("Digite o nome e senha do usuário");
                nomeUsuario = leitor.nextLine();
                senhaUsuario = leitor.nextLine();
            user.login(nomeUsuario,senhaUsuario);
            System.out.println("Selecione o serviço desejado: \n 1-Fazer um tour por seu sistema e Java \n 2-Sair");
                String resposta = leitor.nextLine();
                do{
                    if(resposta.equals("1")) {
                        user.pegarDados();
                        System.out.println("Selecione o serviço desejado: \n 1-Fazer um tour por seu sistema e Java \n 2-Sair");
                        resposta = leitor.nextLine();
                    }
                    }while (resposta != "2");


    }
}