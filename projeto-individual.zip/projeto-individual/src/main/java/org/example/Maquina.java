package org.example;

import java.util.HashMap;

public class Maquina {
    Double cpu,memoria,disco;
    String nome,senha;
    HashMap<String,String> Usuario = new HashMap<>();

    HashMap<String, String> cadastro(){
        Usuario.put(nome,senha);
        return Usuario;
    }
    HashMap<String, String> login(String nomeValidar, String senhaValidar){
        for (String i:
                Usuario.keySet()) {
            if(nomeValidar.equals(i)){
                for (String j:
                        Usuario.values()) {
                    if(senhaValidar.equals(j)){
                        System.out.println("Bem-vindo(a) "+ nome);
                    }else{
                        System.out.println("Nome certo, mas senha inválida. Tente novamente!");
                    }
                }
            }else{
                System.out.println("Nome inválido.Tente novamente!");
            }
        }
        return Usuario;
    }
    String telaSelecao(String resposta){
        if(resposta.equals("1")){
            return "1";
        }else if(resposta.equals("2")){
            return "0";
        }
        return resposta;
    }
    void pegarDados(){
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.arch"));
        System.out.println(System.getProperty("user.name"));
        System.out.println(System.getProperty("user.country"));
        System.out.println(System.getProperty("user.language"));
        System.out.println(System.getProperty("sun.cpu.isalist"));
        System.out.println(System.getProperty("java.class.path"));
        System.out.println(System.getProperty("java.specification.version"));
        System.out.println(System.getProperty("java.version"));
        System.out.println(System.getProperty("java.vm.name"));
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
